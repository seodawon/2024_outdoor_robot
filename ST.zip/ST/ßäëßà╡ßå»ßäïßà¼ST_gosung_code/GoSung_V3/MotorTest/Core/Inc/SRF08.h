
#ifndef INC_SRF08_H_
#define INC_SRF08_H_

//void SRF08_COMMAND();
void SRF08_READ();
void change_SRF08_I2C_address();
//void SRF08_CallBack(I2C_HandleTypeDef *hi2c);
//void SRF08_CallBack1();
//void SRF08_CallBack2();

#endif
