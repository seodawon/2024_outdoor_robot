#ifndef INC_BLE_H_
#define INC_BLE_H_

void BLE_Init(void);
void BLE_CallBack(void);

#endif /* INC_BLE_H_ */
